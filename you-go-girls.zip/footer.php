<footer>
   <div class="container">
       <p>© 2018 You Go Girls – Todos os direitos reservados.</p>
   </div>
    
</footer>
<?php wp_footer();?>
</body>

</html>
