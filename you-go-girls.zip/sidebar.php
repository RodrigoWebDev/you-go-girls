<?php 
    if(is_active_sidebar("barra-lateral")){
        dynamic_sidebar("barra-lateral");
    }
?>