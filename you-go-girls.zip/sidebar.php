<?php 
    if(is_active_sidebar("sidebar-blog")){
        dynamic_sidebar("sidebar-blog");
    }
?>