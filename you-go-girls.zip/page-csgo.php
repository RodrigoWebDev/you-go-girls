<?php get_header();?>
<div class="visual-title visual-title-pages visual-title-pages--csgo">
    <div class="container">
        <div class="row">
            <div class="col-4 col-lg-5">
                <hr>
            </div>
            <div class="col-4 col-lg-2">
                <h2 class="h2-title">Campeonatos</h2>
            </div>
            <div class="col-4 col-lg-5">
                <hr>
            </div>
        </div>
    </div>
</div>
<div class="container campeonatos">
    <div class="row">
        <div class="col-md-8">
        </div>
        <div class="col-md-4">
            <aside class="sidebar">
            </aside>
        </div>
    </div>
</div>
<?php get_footer(); ?>
