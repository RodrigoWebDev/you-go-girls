<div class="post">
    <div class="overlayer d-none"></div>
	<a class="hvr-bounce-to-top hvr-bounce-to-top--black" href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
    <a href="<?php the_permalink(); ?>"><h2 class="text-uppercase font-weight-bold"><?php the_title(); ?></h2></a>
</div>